<?php
session_start();
include_once("config.mysql.php");
include_once("func.mysql.php");

//var_dump($_POST);

$vorname = "";
$nachname = "";
$geschlecht = "";
$rolle = 4;
if(isset($_POST["vorname"])) {
    $vorname = $_POST["vorname"];
}
if(isset($_POST["nachname"])) {
    $nachname = $_POST["nachname"];
}
/*
if(isset($_POST["geburtsdatum"])) {
    $geburtsdatum = $_POST["geburtsdatum"];
}
*/
if(isset($_POST["geschlecht"])) {
    $geschlecht = $_POST["geschlecht"];
}
if(isset($_POST["rolle"])) {
    $rolle = $_POST["rolle"];
}
if($vorname != "" && $nachname != ""){
    $controll = CreateNewAuthor($vorname, $nachname, $geschlecht, $rolle, $conn);
}
if($controll == 0){
    header('location:index.php');
}elseif ($controll == -1){
    echo "Fehler in addController.php";
}

?>
