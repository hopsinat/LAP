<?php
include_once ("config.mysql.php");

function GetGenres($conn){
    $stmtGenre = 'SELECT gen_name as "Genre" FROM movie.genre';
    $stmt = $conn->prepare($stmtGenre);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
$genres = GetGenres($conn);

?>

<!doctype html>
<html lang="en">
    <head>
        <title>Theater</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="favicon.ico">
        <link href="../movie/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <style>
            label {
                width:100%;
                text-align:left;
            }
            input {
                width:100%;
                height:40px;
                margin-bottom:10px;
                display:inline-block;
            }
            .add-container {
                top: -7%;
                padding: 50px 120px;
                font-size: 140%;
                position: relative;
                border-radius: 5px;
                background-color: white;
                border: 1px solid lightblue;
                box-shadow: 1px 4px 5px rgba(0, 0, 0, 0.1);
            }
            .add-button {
                margin:20px auto;
                display:block;
            }
            form div div label {
                width:170px;
                font-size:70%;
            }
            form div div label input {
                width:10%;
                float:right;
                margin-left:10px;
            }
            ::placeholder {
                padding:10px;
                font-size:70%;
            }
        </style>
    </head>

    <body>

         <!-- ----- AUTOR ERFASSEN ----- -->
        <div class="add-container" style="font-size:140%;">
            <div class="add-form">
                <div class="add-title">
                    <h2>Autor erfassen</h2>
                </div>
                <form action="addController.php" method="POST">
                    <div class="data">
                        <label>Vorname:</label>
                        <input type="text" name="vorname" id="titel" placeholder="..." onfocus="this.placeholder = ''" required>
                    </div>
                    <div class="data">
                        <label>Nachname:</label>
                        <input type="text" name="nachname" id="autor" placeholder="..." onfocus="this.placeholder = ''" required>
                    </div>
                    <!--<div class="data">
                        <label>Geburtsdatum:</label>
                        <input type="text" name="geburtsdatum" id="autor" placeholder="..." onfocus="this.placeholder = ''" required>
                    </div>-->
                    <div class="data">
                        <label>Geschlecht:</label>
                        <input type="text" name="geschlecht" id="autor" placeholder="..." onfocus="this.placeholder = ''" required>
                    </div>
                    <div class="data">
                        <label>Rolle:</label>
                        <input type="number" value="4" name="rolle" id="autor" placeholder="Schauspieler=1 / Hausmeister=2 / Reinigungskraft=3 / Autor=4" required>
                    </div>
                    <div class="add-button">
                        <button type="submit" id="add" name="add"/>Speichern</button>
                    </div>
                </form>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="../riesel_alexander1/dist/js/bootstrap.min.js"></script>
    </body>
</html>
