<?php
include_once ("config.mysql.php");

function CreateNewAuthor($vorname, $nachname, $geschlecht, $rolle, $conn){

    $stmt01 = $conn->prepare('insert into person (per_vorname, per_nachname, per_geschlecht, rol_id) values(:vorname, :nachname, :geschlecht, :rolle);');
    $stmt01->bindParam(":vorname", $vorname);
    $stmt01->bindParam(":nachname", $nachname);
    $stmt01->bindParam(":geschlecht", $geschlecht);
    $stmt01->bindParam(":rolle", $rolle);
    if(!$stmt01->execute()){
        echo "Nix geht!";
    } else {
        $stmt01->execute();
    }
}

?>

