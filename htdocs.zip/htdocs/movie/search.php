<?php

$query = 'select dra_name as "Drama", 
            gen_name as "Genre", 
            concat_ws(\' \', per_vorname, per_nachname) as "Autor",
            date_format(eve_termin, \'%a, %d. %b %Y %H:%i\') as "Erstaufführung"
            from drama d natural join genre g natural join person p natural join event e
            order by e.eve_termin ASC';

try
{
    $stmt1 = $conn->prepare($query);
    $stmt1->execute();
    echo '<form method="post">';
    echo '<div class="form-group">
            <label style="font-weight: bold">Suche:</label>
            <input class="inputbox input-field" type="text" style="width: 50%" name="suchfeld" placeholder="Suche..."></div>';
   
    echo '<div class="form-group">
    <label class="col-md-2"></label>
    <input class="suche" type="submit" style="width: 15%;margin-right: 90px;" name="search" value="Suche starten"></div>';
    echo '</form>';

    if(isset($_POST['search']))
    {
        $suchfeld = $_POST['suchfeld'];
        echo '<h2 style="margin:50px auto 50px;">Ergebnis der Suche</h2>';
        $query1 = 'select dra_name as "Drama", 
                    gen_name as "Genre", 
                    concat_ws(\' \', per_vorname, per_nachname) as "Autor",
                    date_format(eve_termin, \'%a, %d. %b %Y %H:%i\') as "Erstaufführung"
                    from drama d natural join genre g natural join person p natural join event e
                    where d.dra_name like ? or g.gen_name like ? or p.per_vorname like ? or p.per_nachname like ? or e.eve_termin like ?
                    order by e.eve_termin ASC';

        $stmt1 = $conn->prepare($query1);
        $suche = '%'.$suchfeld.'%';
        $stmt1->execute([$suche, $suche, $suche, $suche, $suche]);
        echo '<div class="table">
              <div class="row" style="height:50px;">';
        for($i = 0; $i < $stmt1->columnCount(); $i++)
        {
            echo '<div class="col" style="width:auto;font-weight:normal;">'.$stmt1->getColumnMeta($i)['name'].'</div>';
        }
        echo '</div>';
        while($row = $stmt1->fetch(PDO::FETCH_NUM))
        {
            echo '<div class="row">';
            foreach($row as $r)
            {
                echo '<div class="col" style="width:auto;font-weight:normal;">'.$r.'</div>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
} catch(Exception $e)
{
    echo $e->getCode().': '.$e->getMessage();
}