<?php

    try {
        $dbserver = "localhost";
        $user = "root";
        $pw = '';
        $db = "movie";
        $conn = new PDO("mysql:host=$dbserver;dbname=$db", "$user", "$pw");
        $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    } catch(PDOException $e) {
        print "Error: " . $e->getMessage() . "<br/>";
    }

?>