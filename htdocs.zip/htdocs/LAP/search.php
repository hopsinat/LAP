<?php

$query = 'select film_titel as "Titel", 
            date_format(film_erscheinungsdatum, \'%d %M %Y\') as "Erscheinungs-Datum", 
            prod_name as "Produktionsfirma"
            from filmverwaltung.Film f natural join filmverwaltung.Produktionsfirma p
            order by f.film_erscheinungsdatum';

try
{
    echo '<form method="post">';
    echo '<div class="form-group">
        <p>Filmsuche:</p>
        <label style="font-weight: bold">Suche:</label>
        <input class="inputbox input-field" type="text" style="width: 90%; float:right;" name="suchfeld" placeholder="Sie können nach allem suchen"></div>';

    /*
    //Search results shown on load
    $stmt0 = $conn->prepare($query);
    $stmt0->execute();

    echo '<div class="table">
          <div class="row">';
    for($i = 0; $i < $stmt0->columnCount(); $i++)
    {
        echo '<div class="col font-weight-bold">'.$stmt0->getColumnMeta($i)['name'].'</div>';
    }
    echo '<div class="col"></div>';
    echo '</div>'; // row end
    $lastID = 0;
    while($row = $stmt0->fetch(PDO::FETCH_NUM))
    {
        echo '<div class="row">';
            if (strcmp($lastID, $row[1]) == 0) {
                echo '<div class="col"></div><div class="col"></div><div class="col"></div><div class="col">und ' . $row[3] . '</div>';
            } else {
                echo '<div class="col">' . $row[0] .'</div>
                      <div class="col">' . $row[1] . '</div>
                      <div class="col">' . $row[2] . '</div>';
            }
            $lastID = $row[1];
        echo '</div>';
    }
    echo '</div>'; // table end
    */

    echo '<div class="form-group">
    <label class="col-md-2"></label>
    <input type="submit" style="width: 10%; float: right;" name="search" value="Suche starten"></div>';
    echo '</form>';

    if(isset($_POST['search']))
    {
        $suchfeld = $_POST['suchfeld'];
        echo '<h2>Ergebnis der Suche</h2>';
        $query = 'select film_titel as "Titel", 
                    date_format(film_erscheinungsdatum, \'%d %M %Y\') as "Erscheinungs-Datum", 
                    prod_name as "Produktionsfirma"
                    from filmverwaltung.Film f natural join filmverwaltung.Produktionsfirma p
                    order by f.film_erscheinungsdatum';

        $query1 = 'select film_titel as "Titel", 
                    date_format(film_erscheinungsdatum, \'%d %M %Y\') as "Erscheinungs-Datum", 
                    prod_name as "Produktionsfirma"
                    from filmverwaltung.Film f natural join filmverwaltung.Produktionsfirma p 
                    where f.film_titel like ? or f.film_erscheinungsdatum like ? or p.prod_name like ?';

        $stmt1 = $conn->prepare($query1);
        $suche = '%'.$suchfeld.'%';
        $stmt1->execute([$suche, $suche, $suche]);
        echo '<div class="table">
              <div class="row">';
        for($i = 0; $i < $stmt1->columnCount(); $i++)
        {
            echo '<div class="col font-weight-bold">'.$stmt1->getColumnMeta($i)['name'].'</div>';
        }
        echo '</div>';
        while($row = $stmt1->fetch(PDO::FETCH_NUM))
        {
            echo '<div class="row">';
            foreach($row as $r)
            {
                echo '<div class="col">'.$r.'</div>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

} catch(Exception $e) {
    echo $e->getCode().': '.$e->getMessage();
}