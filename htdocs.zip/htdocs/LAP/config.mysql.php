<?php

    try {
        $dbserver = "localhost";
        $user = "root";
        $pw = "";
        $db = "filmverwaltung";

        $conn = new PDO("mysql:host=$dbserver;dbname=$db", "$user", "$pw");
        $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
    
        if ($e->errorInfo[1] == 1062) {
            
            print "PDOException Duplicate error: " . $e->getMessage() . "<br/>";
        } else {
            print "PDOException Error: " . $e->getMessage() . "<br/>";
        }
    }

?>