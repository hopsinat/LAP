<?php
include_once ("config.mysql.php");

function GetGenres($conn){
    $stmtGenre = 'SELECT gen_name as "Genre" FROM movie.genre';
    $stmt = $conn->prepare($stmtGenre);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
$genres = GetGenres($conn);

?>

<!doctype html>
<html lang="en">
    <head>
        <title>Hinzuf�gen</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="favicon.ico">
        <link href="../LAP/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <style>
            label {
                width:100%;
                text-align:left;
            }
            input {
                width:100%;
                height:40px;
                margin-bottom:10px;
                display:inline-block;
            }
            .add-container {
                top: -7%;
                padding: 50px 120px;
                font-size: 140%;
                position: relative;
                border-radius: 5px;
                background-color: white;
                border: 1px solid lightblue;
                box-shadow: 1px 4px 5px rgba(0, 0, 0, 0.1);
            }
            .add-button {
                margin:20px auto;
                display:block;
            }
            form div div label {
                width:100%;
                font-size:140%;
            }
            form div div label input {
                width:70%;
                float:right;
                margin-left:10px;
            }
            ::placeholder {
                padding:10px;
                font-size:70%;
            }
        </style>
    </head>

    <body>

         <!-- ----- HINZUF�GEN FORM ----- -->
        <div class="add-container">
            <div class="add-form">
                <div class="add-title">
                    <h2>Person erfassen</h2>
                </div>
                <form action="addController.php" method="POST">
                        <div class="form-group">
                            <div class="data">
                                <label>Vorname:</label>
                                <input type="text" class="form-control" name="vorname" id="titel" placeholder="..." onfocus="this.placeholder = ''" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="data">
                                <label>Nachname:</label>
                                <input type="text" class="form-control" name="nachname" id="email" placeholder="..." onfocus="this.placeholder = ''" required>
                            </div>
                        </div>
                    <!--<div class="form-group">
                            <div class="data">
                                <label>Geburtsdatum:</label>
                                <input type="text" name="geburtsdatum" id="autor" placeholder="..." onfocus="this.placeholder = ''" required>
                            </div>
                        </div>-->
                        <div class="form-group">
                            <div class="data">
                                <label>Geschlecht:</label>
                                <input type="text" class="form-control" name="geschlecht" id="autor" placeholder="..." onfocus="this.placeholder = ''" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="data">
                                <label>Rolle:</label>
                                <input type="number" class="form-control" name="rolle" id="autor" placeholder="Schauspieler=1 / Hausmeister=2 / Reinigungskraft=3 / Autor=4" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="add-button">
                                <button type="submit" class="btn btn-primary" id="add" name="add"/>Speichern</button>
                            </div>
                         </div>
                </form> <!-- https://getbootstrap.com/docs/4.5/components/forms/ -->

            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="../LAP/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script>

            //onchange="validateEmail()" in <input type="email" einf�gen
            var patt = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            function validateEmail() {
                var str = document.getElementById("email").value;
                var result = patt.test(str);
                if (!result) {
                    var loginButton = document.getElementById("login");
                    loginButton.setAttribute("disabled", "true");
                } else {
                    loginButton.removeAttribute("disabled");
                }
            }
        </script>
    </body>
</html>
